package com.example.android.popularmovies.Fragment;

public class HighRatedMovieFragment {
    // Is it a good user experience to make popular and high rated in separate
    // screens ? Good question, bitch !
}
