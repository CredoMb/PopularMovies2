package com.example.android.popularmovies.Fragment;

import androidx.fragment.app.FragmentPagerAdapter;

public class MoviePagerAdapter {

}
/*extends FragmentPagerAdapter {

}*/
