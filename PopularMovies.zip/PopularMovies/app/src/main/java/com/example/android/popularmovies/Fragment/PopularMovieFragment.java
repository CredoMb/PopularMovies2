package com.example.android.popularmovies.Fragment;

import androidx.fragment.app.Fragment;

public class PopularMovieFragment extends Fragment {
}
