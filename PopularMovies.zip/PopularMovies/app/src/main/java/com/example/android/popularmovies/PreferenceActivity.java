package com.example.android.popularmovies;

public class PreferenceActivity {

}
