package com.udacity.sandwichclub;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.FontsContract;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.udacity.sandwichclub.model.Sandwich;
import com.udacity.sandwichclub.utils.JsonUtils;

import java.util.List;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "extra_position";
    private static final int DEFAULT_POSITION = -1;

    // Variables to store textViews related to the sandwich details
    private ImageView mIngredientsIv;
    private TextView mAlsoKnownTv;
    private TextView mIngredientsTv;
    private TextView mOriginTv;
    private TextView mDescriptionTv;

    // Sandwich variable to store the current sandwich informations
    private Sandwich mSandwich;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Was not able to use butter knife library,
        // it didn't work. According to android studio,
        // it was not compatible with my project.

        // Get the image View from the activity_detail Layout
        mIngredientsIv = findViewById(R.id.image_iv);

        // Get all the textViews that holds the details about the sandwich
        mAlsoKnownTv = findViewById(R.id.also_known_tv);
        mIngredientsTv = findViewById(R.id.ingredients_tv);
        mOriginTv = findViewById(R.id.origin_tv);
        mDescriptionTv = findViewById(R.id.description_tv);

        // Receive the intent from the Main Activity
        Intent intent = getIntent();
        // If the intent is null, display a toast with an error message
        if (intent == null) {
            closeOnError();
        }

        // Get the extra associated with the intent.
        // This extra represent the position of the sandwich
        // that was clicked on
        int position = intent.getIntExtra(EXTRA_POSITION, DEFAULT_POSITION);
        if (position == DEFAULT_POSITION) {
            // EXTRA_POSITION not found in intent
            closeOnError();
            return;
        }

        // Get the array that contains the Json for all the sandwiches
        // present on the screen
        String[] sandwiches = getResources().getStringArray(R.array.sandwich_details);
        String json = sandwiches[position];
        mSandwich = JsonUtils.parseSandwichJson(json);
        if (mSandwich == null) {
            // Sandwich data unavailable
            closeOnError();
            return;
        }

        // Set the text related to the sandwich's details
        populateUI();

        // Set the image of the sandwich on it image view
        Picasso.with(this)
                .load(mSandwich.getImage())
                .placeholder(R.drawable.sandwich_placeholder)
                .error(R.drawable.error)
                .into(mIngredientsIv);

        // Set the name of the sandwich as the activity title
        setTitle(mSandwich.getMainName());

    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, R.string.detail_error_message, Toast.LENGTH_SHORT).show();
    }

    /**
     * Fill all the text info about the sandwich
     */
    private void populateUI() {

        // Get the list for the "alsoKnown" names and the one
        // for the ingredients
        List<String> alsoKnownList = mSandwich.getAlsoKnownAs();
        List<String> ingredientsList = mSandwich.getIngredients();

        // Set all the detailed text on it corresponding
        // TextView
        mAlsoKnownTv.append(makeBoldText(" " + TextUtils.join(", ",alsoKnownList)));
        mIngredientsTv.append(makeBoldText(" " + TextUtils.join(", ",ingredientsList)));
        mOriginTv.append(makeBoldText(" " + mSandwich.getPlaceOfOrigin()));
        mDescriptionTv.append(makeBoldText(" " + mSandwich.getDescription()));

    }

    /**
     * Make bold text
     */
    private Spannable makeBoldText(String text) {

        int textEnd = text.length();
        int textBegin = 0;

        Spannable spannable = new SpannableString(text);
        StyleSpan boldTypeFace = new StyleSpan(Typeface.BOLD);
        spannable.setSpan(boldTypeFace, textBegin, textEnd, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        return spannable;
    }
}
