package com.udacity.sandwichclub.utils;

import android.text.TextUtils;
import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {

        // If the JSON string is empty or null, then return null.
        if (TextUtils.isEmpty(json)) {
            return null;
        }

        // Try to parse the jsonResponse. If there's a problem with the way the JSON
        // is formatted, a JSONException exception object will be thrown.
        // Catch the exception so the app doesn't crash, and print the error message to the logs.
        try {
            JSONObject JSONSandwichObject = new JSONObject(json);
            // Get the Json object that contains the mainName
            JSONObject JSONNameObject = JSONSandwichObject.optJSONObject("name");
            // Get the Json array with the name "alsoKnownAs"
            // This Array contains all the alternative names of the sandwich
            JSONArray JSONAlsoKnownAsArray = JSONNameObject.optJSONArray("alsoKnownAs");
            // Turn the JSONAlsoKnownAsArray into a String list of "alsoKnown" names
            List<String> alsoKnownList = turnJsonArrayToAStringList(JSONAlsoKnownAsArray);

            //Get the JSONArray with the name "ingredients"
            //This Array contains a list of all the ingredients needed to make the sandwich
            JSONArray JSONIngredientsArray = JSONSandwichObject.optJSONArray("ingredients");
            // Turn the JSONIngredientsArray into a String list of "Ingredients"
            List<String> ingredientsList = turnJsonArrayToAStringList(JSONIngredientsArray);

            Sandwich sandwich = new Sandwich(JSONNameObject.optString("mainName"),
                    alsoKnownList,
                    JSONSandwichObject.optString("placeOfOrigin"),
                    JSONSandwichObject.optString("description"),
                    JSONSandwichObject.optString("image"),
                    ingredientsList);

             return sandwich;

        }
        // Catch any exception that occurs and show it in the Log
        catch (Exception e){
            e.printStackTrace();
        }

            return null;
    }

    /** This will extract the element of a JSONArray and turn it into a List of
     * String */

    private static List<String> turnJsonArrayToAStringList(JSONArray JSONArray) {
        List<String> list = new ArrayList<String>();

        if (JSONArray != null && JSONArray.length() > 0) {
            for (int i = 0; i < JSONArray.length(); i++) {
                list.add(JSONArray.optString(i));
            }
        }
        return list;
    }
}
